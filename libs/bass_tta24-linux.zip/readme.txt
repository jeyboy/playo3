BASS_TTA 2.4

� 2002-2012, Sebastian Andersson (sebastian.andersson@gmail.com). All rights reserved.
Portions � 1999-2006 Alexander Djourik. All rights reserved.

All trademarks and other registered names contained in the BASS_TTA
package are the property of their respective owners.


What is BASS_TTA?
=================
BASS_TTA is an extension to the BASS audio library that enables the playback
of The True Audio streams.


What is The True Audio?
=======================
Please visit:

http://www.trueaudio.com


Disclaimer
==========
BASS_TTA is provided "as is" and without warranties of any kind, either express
or implied. The author assumes no liability for damages, direct or consequential,
which may result from the use of BASS_TTA.


Costs
=====
The BASS_TTA library is free to use and distribute as long as you follow the guidelines
of the LGPL.

If you enjoy BASS_TTA, please consider donating money. You may use PayPal to make a donation:

https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=sebastian%2eandersson%40gmail%2ecom&item_name=BASS%20Add%2dOns&item_number=1&no_shipping=1&no_note=1&tax=0&currency_code=EUR